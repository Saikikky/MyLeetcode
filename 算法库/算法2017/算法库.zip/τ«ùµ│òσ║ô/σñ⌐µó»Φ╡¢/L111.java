import java.util.Scanner;

/**
 * Created by wang on 16/7/10.
 */
public class L111 {
    public static void main(String [] args)
    {
        String a, b;
        Scanner sc = new Scanner(System.in);

        a = sc.nextLine();
        b = sc.nextLine();

        StringBuilder s = new StringBuilder(a);
        //回去看正则表达式
    }
}
