/**
 * Created by wang on 16/7/8.
 */
public class L101 {
    public static void main(String [] args)
    {
        System.out.print("Hello World!");

    }
}
