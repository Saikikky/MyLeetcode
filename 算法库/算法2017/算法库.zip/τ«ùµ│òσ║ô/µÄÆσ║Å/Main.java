import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/**
 * Created by Treasure_ on 16/3/6.
 */

public class Main
{

    public static void main(String [] args)
    {

        //ArrayList的排序
        /*
        ArrayList<Integer>  al = new ArrayList<Integer>();

        for(int i = 10; i >= -1; i--)
        {
            al.add(i);
        }
        Collections.sort(al, new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                if (o1 > o2) return -1;
                else if (o1 < o2) return 1;
                else return 0;
            }
        });
        for (int i:al)
        {
            System.out.println(i);
        }
        */

        //Set

    }
}
