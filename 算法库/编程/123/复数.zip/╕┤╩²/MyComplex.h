#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "MyMath.h"


void InputComplex(REAL *rp,REAL *ip);
void OutputComplex(REAL rp,REAL ip);
